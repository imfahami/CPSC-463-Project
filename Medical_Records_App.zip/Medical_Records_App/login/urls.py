from django.conf.urls import url
from . import views


app_name = 'login'

urlpatterns = [
    url(r'^patient_login/', views.patient_login_view, name="patient login"),
    url(r'^doctor_login/', views.doctor_login_view, name="doctor login"),

]
