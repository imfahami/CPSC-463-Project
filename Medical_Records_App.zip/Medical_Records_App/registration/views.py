from django.shortcuts import render
from .forms import PatientSignIn, DoctorSignIn, PatientSignUp
from .models import Patient, Doctor
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User

# Create your views here.
def patient_login(request):
    pform_class = PatientSignIn
    pform = pform_class(request.POST)
    if request.method == 'POST':
        pform = PatientSignIn(request.POST)
        if pform.is_valid():
            username_form = pform.cleaned_data['username']
            password_form = pform.cleaned_data['password']
            users = authenticate(username = username_form, password = password_form)
            if users is not None:
                if users.is_active:
                    login(request, users)
            else:
                return HttpResponse("<h1>Not Valid</h1>")
        else:
            pform = PatientSignIn()
    return render(request, 'landing_page.html', {'form': pform})


def doctor_login(request):
    Dform = DoctorSignIn()
    return render(request, 'doctor_landing.html', {'form': Dform})


def patient_signup(request):
    Psignup_class = PatientSignUp(request.POST)

    if Psignup_class.is_valid():
        Psignup_class.save()
        username = Psignup_class.cleaned_data['username']
        password = Psignup_class.cleaned_data['password']
        user = authenticate(username=username, password=password)
        login(request,user)
    else:
        Psignup_class = PatientSignUp()
    return render(request, 'patient_signup.html', {'form': Psignup_class})


def veiw_all_users():
    all_patient = Patient.objects.all()
    patient = Patient
    html = ''
    for patient in all_patient:
        html += str(patient.first_name) + "\n" + str(patient.last_name) + "\n"
    return HttpResponse(html)