from django.db import models


# Create your models here.

class Doctor(models.Model):
    first_name = models.CharField(max_length=50, null= True, blank= True)
    last_name = models.CharField(max_length=50, null= True, blank= True)
    username = models.CharField(max_length=60, null= True, blank= True)
    password = models.CharField(max_length=50, null= True, blank= True)


class Patient(models.Model):
    first_name = models.CharField(max_length=50, null= True, blank= True)
    last_name = models.CharField(max_length=50, null= True, blank= True)
    username = models.CharField(max_length=60, null= True, blank= True)
    password = models.CharField(max_length=50, null= True, blank= True)
    email = models.CharField(max_length=50, null= True, blank= True)
    dob = models.DateField(max_length=8, null= True, blank= True)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, null= True, blank= True)
    region = models.CharField(max_length=80, null= True, blank= True)
    #sex = (
    #    ('M', 'Male'),
    #    ('F', 'Female'),)


