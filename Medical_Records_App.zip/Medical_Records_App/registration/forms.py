from django import forms
from django.forms import ModelForm
from .models import Patient, Doctor
from django.contrib.auth.models import User


class PatientSignIn(ModelForm):
    class Meta:
        model = Patient
        fields = ['username', 'password']


class DoctorSignIn(ModelForm):
    class Meta:
        model = Doctor
        fields = ['username', 'password']


class PatientSignUp(ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username', 'password', 'email']
